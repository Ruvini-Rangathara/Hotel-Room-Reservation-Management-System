import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class MealPackagesAdminController implements Initializable {

    public AnchorPane mealPackagesAdminContext;
    public TextField insertMealPrice;
    public ChoiceBox<String> mealChoiceBox;
    public ChoiceBox<String> mealTypeChoiceBox;

    public TableView mealTableAdmin;
    public TableColumn colMealType;
    public TableColumn colMeal;
    public TableColumn colMealPrice;


    String[] typeChoice = {"Local Meals","Chinese Meals","French Meals"};
    String[] mealChoice = {"Breakfast","Lunch","Dinner"};

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        mealChoiceBox.getItems().addAll(mealChoice);
        mealTypeChoiceBox.getItems().addAll(typeChoice);

        colMealType.setCellValueFactory(new PropertyValueFactory("mealType"));
        colMeal.setCellValueFactory(new PropertyValueFactory("meal"));
        colMealPrice.setCellValueFactory(new PropertyValueFactory("mealPrice"));
        loadMeals();
    }

    private void loadMeals() {
        ObservableList<MealsTM> cObList= FXCollections.observableArrayList();
        for (Meals c: MealDatabase.mTable) {
            MealsTM tm= new MealsTM(c.getMealType(),c.getMeal(),c.getMealPrice());
            cObList.add(tm);
            mealTableAdmin.setItems(cObList);
        }
    }

    public void modifyMealOnAction(ActionEvent actionEvent) {

    }

    public void deleteMealOnAction(ActionEvent actionEvent) {

    }

    public void addMealOnAction(ActionEvent actionEvent) {
        Meals m1=new Meals(
                mealTypeChoiceBox.getValue(),
                mealChoiceBox.getValue(),
                Integer.parseInt(insertMealPrice.getText())
        );
        MealDatabase.mTable.add(m1);
        loadMeals();
    }

    public void backOnAction(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) mealPackagesAdminContext.getScene().getWindow();
        stage.setTitle("Blue Ocean Room Reservation system");
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("Admin.fxml"))));
        stage.centerOnScreen();
    }


}
